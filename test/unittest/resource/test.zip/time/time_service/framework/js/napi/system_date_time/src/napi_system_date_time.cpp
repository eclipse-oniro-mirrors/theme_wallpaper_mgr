/*
 * Copyright (C) 2022 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "napi_system_date_time.h"

#include "parameters.h"
#include "napi_work.h"
#include "napi_utils.h"
#include "time_hilog.h"
#include "time_service_client.h"

using namespace OHOS::MiscServices;

namespace OHOS {
namespace MiscServices {
namespace Time {

constexpr int64_t SECONDS_TO_NANO = 1000000000;
constexpr int64_t SECONDS_TO_MILLI = 1000;
constexpr int64_t NANO_TO_MILLI = SECONDS_TO_NANO / SECONDS_TO_MILLI;
constexpr int32_t STARTUP = 0;
constexpr int32_t ACTIVE = 1;
const std::string TIMEZONE_KEY = "persist.time.timezone";

napi_value NapiSystemDateTime::SystemDateTimeInit(napi_env env, napi_value exports)
{
    napi_value timeType = nullptr;
    napi_value startup = nullptr;
    napi_value active = nullptr;
    NAPI_CALL(env, napi_create_int32(env, STARTUP, &startup));
    NAPI_CALL(env, napi_create_int32(env, ACTIVE, &active));
    NAPI_CALL(env, napi_create_object(env, &timeType));
    NAPI_CALL(env, napi_set_named_property(env, timeType, "STARTUP", startup));
    NAPI_CALL(env, napi_set_named_property(env, timeType, "ACTIVE", active));

    napi_property_descriptor descriptors[] = {
        DECLARE_NAPI_STATIC_FUNCTION("setTime", SetTime),
        DECLARE_NAPI_STATIC_FUNCTION("getCurrentTime", GetCurrentTime),
        DECLARE_NAPI_STATIC_FUNCTION("getRealActiveTime", GetRealActiveTime),
        DECLARE_NAPI_STATIC_FUNCTION("getRealTime", GetRealTime),
        DECLARE_NAPI_STATIC_FUNCTION("getTime", GetTime),
        DECLARE_NAPI_STATIC_FUNCTION("setDate", SetDate),
        DECLARE_NAPI_STATIC_FUNCTION("getDate", GetDate),
        DECLARE_NAPI_STATIC_FUNCTION("setTimezone", SetTimezone),
        DECLARE_NAPI_STATIC_FUNCTION("getTimezone", GetTimezone),
        DECLARE_NAPI_STATIC_FUNCTION("getUptime", GetUptime),
        DECLARE_NAPI_STATIC_FUNCTION("getTimezoneSync", GetTimezoneSync),
        DECLARE_NAPI_STATIC_PROPERTY("TimeType", timeType),
    };

    napi_status status =
        napi_define_properties(env, exports, sizeof(descriptors) / sizeof(napi_property_descriptor), descriptors);
    if (status != napi_ok) {
        TIME_HILOGE(TIME_MODULE_JS_NAPI, "define manager properties failed");
        return NapiUtils::GetUndefinedValue(env);
    }
    return exports;
}

napi_value NapiSystemDateTime::SetTime(napi_env env, napi_callback_info info)
{
    struct SetTimeContext : public ContextBase {
        int64_t time = 0;
    };
    auto *setTimeContext = new SetTimeContext();
    auto inputParser = [env, setTimeContext](size_t argc, napi_value *argv) {
        CHECK_ARGS_RETURN_VOID(TIME_MODULE_JS_NAPI, setTimeContext, argc >= ARGC_ONE, "invalid arguments",
            JsErrorCode::PARAMETER_ERROR);
        setTimeContext->status = napi_get_value_int64(env, argv[ARGV_FIRST], &setTimeContext->time);
        CHECK_ARGS_RETURN_VOID(TIME_MODULE_JS_NAPI, setTimeContext, setTimeContext->status == napi_ok, "invalid time",
            JsErrorCode::PARAMETER_ERROR);
        setTimeContext->status = napi_ok;
    };
    setTimeContext->GetCbInfo(env, info, inputParser);
    auto executor = [setTimeContext]() {
        auto innerCode = TimeServiceClient::GetInstance()->SetTimeV9(setTimeContext->time);
        if (innerCode != JsErrorCode::ERROR_OK) {
            setTimeContext->errCode = innerCode;
            setTimeContext->status = napi_generic_failure;
        }
    };
    auto complete = [env](napi_value &output) { output = NapiUtils::GetUndefinedValue(env); };
    return NapiWork::AsyncEnqueue(env, setTimeContext, "SetTime", executor, complete);
}

napi_value NapiSystemDateTime::SetDate(napi_env env, napi_callback_info info)
{
    struct SetDateContext : public ContextBase {
        int64_t time = 0;
    };
    auto *setDateContext = new SetDateContext();
    auto inputParser = [env, setDateContext](size_t argc, napi_value *argv) {
        CHECK_ARGS_RETURN_VOID(TIME_MODULE_JS_NAPI, setDateContext, argc >= ARGC_ONE, "invalid arguments",
            JsErrorCode::PARAMETER_ERROR);
        napi_valuetype valueType = napi_undefined;
        napi_typeof(env, argv[ARGV_FIRST], &valueType);
        if (valueType == napi_number) {
            napi_get_value_int64(env, argv[ARGV_FIRST], &setDateContext->time);
            CHECK_ARGS_RETURN_VOID(TIME_MODULE_JS_NAPI, setDateContext, setDateContext->time >= 0, "invalid time",
                JsErrorCode::PARAMETER_ERROR);
        } else {
            bool hasProperty = false;
            napi_valuetype resValueType = napi_undefined;
            napi_has_named_property(env, argv[ARGV_FIRST], "getTime", &hasProperty);
            CHECK_ARGS_RETURN_VOID(TIME_MODULE_JS_NAPI, setDateContext, hasProperty, "getTime failed",
                JsErrorCode::PARAMETER_ERROR);
            napi_value getTimeFunc = nullptr;
            napi_get_named_property(env, argv[0], "getTime", &getTimeFunc);
            napi_value getTimeResult = nullptr;
            napi_call_function(env, argv[0], getTimeFunc, 0, nullptr, &getTimeResult);
            napi_typeof(env, getTimeResult, &resValueType);
            CHECK_ARGS_RETURN_VOID(TIME_MODULE_JS_NAPI, setDateContext, resValueType == napi_number, "type mismatch",
                JsErrorCode::PARAMETER_ERROR);
            setDateContext->status = napi_get_value_int64(env, getTimeResult, &setDateContext->time);
        }
        CHECK_ARGS_RETURN_VOID(TIME_MODULE_JS_NAPI, setDateContext, setDateContext->status == napi_ok, "invalid time",
            JsErrorCode::PARAMETER_ERROR);
        setDateContext->status = napi_ok;
    };
    setDateContext->GetCbInfo(env, info, inputParser);
    auto executor = [setDateContext]() {
        auto innerCode = TimeServiceClient::GetInstance()->SetTimeV9(setDateContext->time);
        if (innerCode != JsErrorCode::ERROR_OK) {
            setDateContext->errCode = innerCode;
            setDateContext->status = napi_generic_failure;
        }
    };
    auto complete = [env](napi_value &output) { output = NapiUtils::GetUndefinedValue(env); };
    return NapiWork::AsyncEnqueue(env, setDateContext, "SetDate", executor, complete);
}

napi_value NapiSystemDateTime::GetRealActiveTime(napi_env env, napi_callback_info info)
{
    struct GetRealActiveTimeContext : public ContextBase {
        int64_t time = 0;
        bool isNano = false;
    };
    auto *getRealActiveTimeContext = new GetRealActiveTimeContext();
    auto inputParser = [env, getRealActiveTimeContext](size_t argc, napi_value *argv) {
        if (argc >= ARGC_ONE) {
            napi_valuetype valueType = napi_undefined;
            napi_typeof(env, argv[ARGV_FIRST], &valueType);
            if (valueType == napi_boolean) {
                getRealActiveTimeContext->status =
                    napi_get_value_bool(env, argv[ARGV_FIRST], &getRealActiveTimeContext->isNano);
                CHECK_ARGS_RETURN_VOID(TIME_MODULE_JS_NAPI, getRealActiveTimeContext,
                    getRealActiveTimeContext->status == napi_ok, "invalid isNano", JsErrorCode::PARAMETER_ERROR);
            }
        }
        getRealActiveTimeContext->status = napi_ok;
    };
    getRealActiveTimeContext->GetCbInfo(env, info, inputParser);
    auto executor = [getRealActiveTimeContext]() {
        int32_t innerCode;
        if (getRealActiveTimeContext->isNano) {
            innerCode = TimeServiceClient::GetInstance()->GetMonotonicTimeNs(getRealActiveTimeContext->time);
        } else {
            innerCode = TimeServiceClient::GetInstance()->GetMonotonicTimeMs(getRealActiveTimeContext->time);
        }
        if (innerCode != JsErrorCode::ERROR_OK) {
            getRealActiveTimeContext->errCode = NapiUtils::ConvertErrorCode(innerCode);
            getRealActiveTimeContext->status = napi_generic_failure;
        }
    };
    auto complete = [env, getRealActiveTimeContext](napi_value &output) {
        getRealActiveTimeContext->status = napi_create_int64(env, getRealActiveTimeContext->time, &output);
        CHECK_STATUS_RETURN_VOID(TIME_MODULE_JS_NAPI, getRealActiveTimeContext,
            "convert native object to javascript object failed", JsErrorCode::ERROR);
    };
    return NapiWork::AsyncEnqueue(env, getRealActiveTimeContext, "GetRealActiveTime", executor, complete);
}

napi_value NapiSystemDateTime::GetCurrentTime(napi_env env, napi_callback_info info)
{
    struct GetCurrentTimeContext : public ContextBase {
        int64_t time = 0;
        bool isNano = false;
    };
    auto *getCurrentTimeContext = new GetCurrentTimeContext();
    auto inputParser = [env, getCurrentTimeContext](size_t argc, napi_value *argv) {
        if (argc >= ARGC_ONE) {
            napi_valuetype valueType = napi_undefined;
            napi_typeof(env, argv[ARGV_FIRST], &valueType);
            if (valueType == napi_boolean) {
                getCurrentTimeContext->status =
                    napi_get_value_bool(env, argv[ARGV_FIRST], &getCurrentTimeContext->isNano);
                CHECK_ARGS_RETURN_VOID(TIME_MODULE_JS_NAPI, getCurrentTimeContext,
                    getCurrentTimeContext->status == napi_ok, "invalid isNano", JsErrorCode::PARAMETER_ERROR);
            }
        }
        getCurrentTimeContext->status = napi_ok;
    };
    getCurrentTimeContext->GetCbInfo(env, info, inputParser);
    auto executor = [getCurrentTimeContext]() {
        int32_t innerCode;
        if (getCurrentTimeContext->isNano) {
            innerCode = TimeServiceClient::GetInstance()->GetWallTimeNs(getCurrentTimeContext->time);
        } else {
            innerCode = TimeServiceClient::GetInstance()->GetWallTimeMs(getCurrentTimeContext->time);
        }
        if (innerCode != JsErrorCode::ERROR_OK) {
            getCurrentTimeContext->errCode = innerCode;
            getCurrentTimeContext->status = napi_generic_failure;
        }
    };
    auto complete = [getCurrentTimeContext, env](napi_value &output) {
        getCurrentTimeContext->status = napi_create_int64(env, getCurrentTimeContext->time, &output);
        CHECK_STATUS_RETURN_VOID(TIME_MODULE_JS_NAPI, getCurrentTimeContext,
            "convert native object to javascript object failed", JsErrorCode::ERROR);
    };
    return NapiWork::AsyncEnqueue(env, getCurrentTimeContext, "GetCurrentTime", executor, complete);
}

napi_value NapiSystemDateTime::GetTime(napi_env env, napi_callback_info info)
{
    struct GetTimeContext : public ContextBase {
        int64_t time = 0;
        bool isNano = false;
    };
    auto *getTimeContext = new GetTimeContext();
    auto inputParser = [env, getTimeContext](size_t argc, napi_value *argv) {
        if (argc >= ARGC_ONE) {
            napi_valuetype valueType = napi_undefined;
            napi_typeof(env, argv[ARGV_FIRST], &valueType);
            if (valueType == napi_boolean) {
                getTimeContext->status = napi_get_value_bool(env, argv[ARGV_FIRST], &getTimeContext->isNano);
                CHECK_ARGS_RETURN_VOID(TIME_MODULE_JS_NAPI, getTimeContext, getTimeContext->status == napi_ok,
                                       "invalid isNano", JsErrorCode::PARAMETER_ERROR);
            }
        }
        getTimeContext->status = napi_ok;
    };
    getTimeContext->GetCbInfo(env, info, inputParser, true);
    auto executor = [getTimeContext]() {
        int32_t innerCode = GetDeviceTime(CLOCK_REALTIME, getTimeContext->isNano, getTimeContext->time);
        if (innerCode != JsErrorCode::ERROR_OK) {
            getTimeContext->errCode = innerCode;
            getTimeContext->status = napi_generic_failure;
        }
    };
    auto complete = [getTimeContext](napi_value &output) {
        getTimeContext->status = napi_create_int64(getTimeContext->env, getTimeContext->time, &output);
        CHECK_STATUS_RETURN_VOID(TIME_MODULE_JS_NAPI, getTimeContext,
                                 "convert native object to javascript object failed", JsErrorCode::ERROR);
    };
    return NapiWork::SyncEnqueue(env, getTimeContext, "GetTime", executor, complete);
}

napi_value NapiSystemDateTime::GetRealTime(napi_env env, napi_callback_info info)
{
    struct GetRealTimeContext : public ContextBase {
        int64_t time = 0;
        bool isNano = false;
    };
    auto *getRealTimeContext = new GetRealTimeContext();
    auto inputParser = [env, getRealTimeContext](size_t argc, napi_value *argv) {
        if (argc >= ARGC_ONE) {
            napi_valuetype valueType = napi_undefined;
            napi_typeof(env, argv[ARGV_FIRST], &valueType);
            if (valueType == napi_boolean) {
                getRealTimeContext->status = napi_get_value_bool(env, argv[ARGV_FIRST], &getRealTimeContext->isNano);
                CHECK_ARGS_RETURN_VOID(TIME_MODULE_JS_NAPI, getRealTimeContext, getRealTimeContext->status == napi_ok,
                    "invalid isNano", JsErrorCode::PARAMETER_ERROR);
            }
        }
        getRealTimeContext->status = napi_ok;
    };
    getRealTimeContext->GetCbInfo(env, info, inputParser);
    auto executor = [getRealTimeContext]() {
        int32_t innerCode;
        if (getRealTimeContext->isNano) {
            innerCode = TimeServiceClient::GetInstance()->GetBootTimeNs(getRealTimeContext->time);
        } else {
            innerCode = TimeServiceClient::GetInstance()->GetBootTimeMs(getRealTimeContext->time);
        }
        if (innerCode != JsErrorCode::ERROR_OK) {
            getRealTimeContext->errCode = innerCode;
            getRealTimeContext->status = napi_generic_failure;
        }
    };
    auto complete = [getRealTimeContext](napi_value &output) {
        getRealTimeContext->status = napi_create_int64(getRealTimeContext->env, getRealTimeContext->time, &output);
        CHECK_STATUS_RETURN_VOID(TIME_MODULE_JS_NAPI, getRealTimeContext,
            "convert native object to javascript object failed", JsErrorCode::ERROR);
    };
    return NapiWork::AsyncEnqueue(env, getRealTimeContext, "GetRealTime", executor, complete);
}

napi_value NapiSystemDateTime::GetUptime(napi_env env, napi_callback_info info)
{
    struct GetUpTimeContext : public ContextBase {
        int64_t time = 0;
        int32_t timeType = STARTUP;
        bool isNanoseconds = false;
    };
    auto *getUpTimeContext = new GetUpTimeContext();
    auto inputParser = [env, getUpTimeContext](size_t argc, napi_value *argv) {
        getUpTimeContext->status = napi_get_value_int32(env, argv[ARGV_FIRST], &getUpTimeContext->timeType);
        CHECK_ARGS_RETURN_VOID(TIME_MODULE_JS_NAPI, getUpTimeContext, getUpTimeContext->status == napi_ok,
                               "invalid timeType", JsErrorCode::PARAMETER_ERROR);
        CHECK_ARGS_RETURN_VOID(TIME_MODULE_JS_NAPI, getUpTimeContext,
            (getUpTimeContext->timeType >= STARTUP && getUpTimeContext->timeType <= ACTIVE), "invalid timeType",
            JsErrorCode::PARAMETER_ERROR);
        if (argc >= ARGC_TWO) {
            napi_valuetype valueType = napi_undefined;
            napi_typeof(env, argv[ARGV_SECOND], &valueType);
            if (valueType == napi_boolean) {
                getUpTimeContext->status =
                    napi_get_value_bool(env, argv[ARGV_SECOND], &getUpTimeContext->isNanoseconds);
                CHECK_ARGS_RETURN_VOID(TIME_MODULE_JS_NAPI, getUpTimeContext, getUpTimeContext->status == napi_ok,
                    "get isNanoseconds failed", JsErrorCode::PARAMETER_ERROR);
            }
        }
        getUpTimeContext->status = napi_ok;
    };
    getUpTimeContext->GetCbInfo(env, info, inputParser, true);
    auto executor = [getUpTimeContext]() {
        int32_t innerCode;
        if (getUpTimeContext->timeType == STARTUP) {
            innerCode = GetDeviceTime(CLOCK_BOOTTIME, getUpTimeContext->isNanoseconds, getUpTimeContext->time);
        } else {
            innerCode = GetDeviceTime(CLOCK_MONOTONIC, getUpTimeContext->isNanoseconds, getUpTimeContext->time);
        }
        if (innerCode != JsErrorCode::ERROR_OK) {
            getUpTimeContext->errCode = innerCode;
            getUpTimeContext->status = napi_generic_failure;
        }
    };
    auto complete = [getUpTimeContext](napi_value &output) {
        getUpTimeContext->status = napi_create_int64(getUpTimeContext->env, getUpTimeContext->time, &output);
        CHECK_STATUS_RETURN_VOID(TIME_MODULE_JS_NAPI, getUpTimeContext,
                                 "convert native object to javascript object failed", JsErrorCode::ERROR);
    };
    return NapiWork::SyncEnqueue(env, getUpTimeContext, "GetUpTime", executor, complete);
}

napi_value NapiSystemDateTime::GetDate(napi_env env, napi_callback_info info)
{
    struct GetDateContext : public ContextBase {
        int64_t time = 0;
    };
    auto *getDateContext = new GetDateContext();
    auto inputParser = [getDateContext](size_t argc, napi_value *argv) { getDateContext->status = napi_ok; };
    getDateContext->GetCbInfo(env, info, inputParser);
    auto executor = [getDateContext]() {
        auto innerCode = TimeServiceClient::GetInstance()->GetWallTimeMs(getDateContext->time);
        if (innerCode != JsErrorCode::ERROR_OK) {
            getDateContext->errCode = innerCode;
            getDateContext->status = napi_generic_failure;
        }
    };
    auto complete = [env, getDateContext](napi_value &output) {
        getDateContext->status = napi_create_date(env, getDateContext->time, &output);
        CHECK_STATUS_RETURN_VOID(TIME_MODULE_JS_NAPI, getDateContext,
            "convert native object to javascript object failed", JsErrorCode::ERROR);
    };

    return NapiWork::AsyncEnqueue(env, getDateContext, "GetDate", executor, complete);
}

napi_value NapiSystemDateTime::SetTimezone(napi_env env, napi_callback_info info)
{
    struct SetTimezoneContext : public ContextBase {
        std::string timezone;
    };
    auto *setTimezoneContext = new SetTimezoneContext();
    auto inputParser = [env, setTimezoneContext](size_t argc, napi_value *argv) {
        CHECK_ARGS_RETURN_VOID(TIME_MODULE_JS_NAPI, setTimezoneContext, argc >= ARGC_ONE, "invalid arguments",
            JsErrorCode::PARAMETER_ERROR);
        setTimezoneContext->status = NapiUtils::GetValue(env, argv[ARGV_FIRST], setTimezoneContext->timezone);
        CHECK_ARGS_RETURN_VOID(TIME_MODULE_JS_NAPI, setTimezoneContext, setTimezoneContext->status == napi_ok,
            "invalid timezone", JsErrorCode::PARAMETER_ERROR);
        setTimezoneContext->status = napi_ok;
    };
    setTimezoneContext->GetCbInfo(env, info, inputParser);
    auto executor = [setTimezoneContext]() {
        auto innerCode = TimeServiceClient::GetInstance()->SetTimeZoneV9(setTimezoneContext->timezone);
        if (innerCode != JsErrorCode::ERROR_OK) {
            setTimezoneContext->errCode = innerCode;
            setTimezoneContext->status = napi_generic_failure;
        }
    };
    auto complete = [env](napi_value &output) { output = NapiUtils::GetUndefinedValue(env); };
    return NapiWork::AsyncEnqueue(env, setTimezoneContext, "SetTimezone", executor, complete);
}

napi_value NapiSystemDateTime::GetTimezone(napi_env env, napi_callback_info info)
{
    struct GetTimezoneContext : public ContextBase {
        std::string timezone;
    };
    auto *getTimezoneContext = new GetTimezoneContext();
    auto inputParser = [getTimezoneContext](size_t argc, napi_value *argv) {
        getTimezoneContext->status = napi_ok;
    };
    getTimezoneContext->GetCbInfo(env, info, inputParser);

    auto executor = [getTimezoneContext]() {
        auto innerCode = TimeServiceClient::GetInstance()->GetTimeZone(getTimezoneContext->timezone);
        if (innerCode != JsErrorCode::ERROR_OK) {
            getTimezoneContext->errCode = innerCode;
            getTimezoneContext->status = napi_generic_failure;
        }
    };
    auto complete = [env, getTimezoneContext](napi_value &output) {
        getTimezoneContext->status = napi_create_string_utf8(env, getTimezoneContext->timezone.c_str(),
            getTimezoneContext->timezone.size(), &output);
        TIME_HILOGI(TIME_MODULE_JS_NAPI, "%{public}s, ", getTimezoneContext->timezone.c_str());
        CHECK_STATUS_RETURN_VOID(TIME_MODULE_JS_NAPI, getTimezoneContext,
            "convert native object to javascript object failed", JsErrorCode::ERROR);
    };
    return NapiWork::AsyncEnqueue(env, getTimezoneContext, "GetTimezone", executor, complete);
}

napi_value NapiSystemDateTime::GetTimezoneSync(napi_env env, napi_callback_info info)
{
    struct GetTimezoneContext : public ContextBase {
        std::string timezone;
    };
    auto *getTimezoneContext = new GetTimezoneContext();
    auto inputParser = [getTimezoneContext](size_t argc, napi_value *argv) { getTimezoneContext->status = napi_ok; };
    getTimezoneContext->GetCbInfo(env, info, inputParser, true);

    auto executor = [getTimezoneContext]() {
        auto innerCode = GetTimezone(getTimezoneContext->timezone);
        if (innerCode != JsErrorCode::ERROR_OK) {
            getTimezoneContext->errCode = innerCode;
            getTimezoneContext->status = napi_generic_failure;
        }
    };
    auto complete = [env, getTimezoneContext](napi_value &output) {
        getTimezoneContext->status = napi_create_string_utf8(env, getTimezoneContext->timezone.c_str(),
            getTimezoneContext->timezone.size(), &output);
        TIME_HILOGI(TIME_MODULE_JS_NAPI, "current timezone %{public}s, ", getTimezoneContext->timezone.c_str());
        CHECK_STATUS_RETURN_VOID(TIME_MODULE_JS_NAPI, getTimezoneContext,
            "convert native object to javascript object failed", JsErrorCode::ERROR);
    };
    return NapiWork::SyncEnqueue(env, getTimezoneContext, "GetTimezone", executor, complete);
}

int32_t NapiSystemDateTime::GetDeviceTime(clockid_t clockId, bool isNano, int64_t &time)
{
    struct timespec tv {};
    if (clock_gettime(clockId, &tv) < 0) {
        TIME_HILOGE(TIME_MODULE_SERVICE, "failed clock_gettime, errno: %{public}s", strerror(errno));
        return ERROR;
    }

    if (isNano) {
        time = tv.tv_sec * SECONDS_TO_NANO + tv.tv_nsec;
    } else {
        time = tv.tv_sec * SECONDS_TO_MILLI + tv.tv_nsec / NANO_TO_MILLI;
    }
    return ERROR_OK;
}

int32_t NapiSystemDateTime::GetTimezone(std::string &timezone)
{
    timezone = system::GetParameter(TIMEZONE_KEY, "Asia/Shanghai");
    if (timezone.empty()) {
        TIME_HILOGW(TIME_MODULE_SERVICE, "No found timezone from system parameter.");
        return ERROR;
    }
    return ERROR_OK;
}
} // namespace Time
} // namespace MiscServices
} // namespace OHOS